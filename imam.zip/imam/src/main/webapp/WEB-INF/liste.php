<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Gestion des utilisateurs</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <section>
        <h1 id="titreP">Liste des utilisateurs</h1>
        <?php
        // Connexion à la base de données
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "myDB";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Vérifier la connexion
        if ($conn->connect_error) {
            die("Connexion échouée: " . $conn->connect_error);
        }

        // Récupérer les utilisateurs
        $sql = "SELECT id, nom, prenom, login, password FROM utilisateurs";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table border='1' cellspacing='0' cellpadding='10'>";
            echo "<tr><th>ID</th><th>Nom</th><th>Prénom</th><th>Login</th><th>Password</th><th colspan='2'>Action</th></tr>";

            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["nom"] . "</td>";
                echo "<td>" . $row["prenom"] . "</td>";
                echo "<td>" . $row["login"] . "</td>";
                echo "<td>" . $row["password"] . "</td>";
                echo "<td><a href='modifier.php?id=" . $row["id"] . "'>Modifier</a></td>";
                echo "<td><a href='supprimer.php?id=" . $row["id"] . "' onclick='return confirm(\"Etes vous sûr de vouloir supprimer ?\")'>Supprimer</a></td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "Désolé, la liste des utilisateurs est vide pour le moment !";
        }

        $conn->close();
        ?>
    </section>
    <?php include 'footer.php'; ?>
</body>
</html>