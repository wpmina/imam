<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myDB";

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connexion échouée: " . $conn->connect_error);
}

// Récupérer les données de l'utilisateur à modifier
$id = $_GET["id"];
$sql = "SELECT nom, prenom, login, password FROM utilisateurs WHERE id=$id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $nom = $row["nom"];
    $prenom = $row["prenom"];
    $login = $row["login"];
    $password = $row["password"];
} else {
    echo "Utilisateur non trouvé.";
}

// Traitement du formulaire de modification
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $login = $_POST["login"];
    $password = $_POST["password"];

    $sql = "UPDATE utilisateurs SET nom='$nom', prenom='$prenom', login='$login', password='$password' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Utilisateur modifié avec succès.";
    } else {
        echo "Erreur: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Modifier un utilisateur</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <section>
        <h1 id="titreP">Modifier un utilisateur</h1>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?id=$id";?>">
            <label for="nom">Nom :</label>
            <input type="text" id="nom" name="nom" value="<?php echo $nom;?>" required>

            <label for="prenom">Prénom :</label>
            <input type="text" id="prenom" name="prenom" value="<?php echo $prenom;?>" required>

            <label for="login">Login :</label>
            <input type="text" id="login" name="login" value="<?php echo $login;?>" required>

            <label for="password">Password :</label>
            <input type="password" id="password" name="password" value="<?php echo $password;?>" required>

            <input type="submit" value="Modifier">
        </form>
    </section>
    <?php include 'footer.php'; ?>
</body>
</html>